package br.com.etechoracio.exercicio20;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercicio20Application {

	public static void main(String[] args) {
		SpringApplication.run(Exercicio20Application.class, args);
	}

}
